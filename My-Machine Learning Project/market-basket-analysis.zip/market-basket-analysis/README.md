# Market-Basket-Analysis

The task is to implement a system finding frequent itemsets (aka market-basket analysis), analyzing IMDb database.

In this project, A-priori and SON algorithm are implemented in Spark.

In the repository you can fine the Colab notebook with the code of the project and the PDF with the report of the project.
